package TrabalhoFinalprograma;

public interface Classificar {
	
	public void classificar(int classificacao) throws ClassificacaoForaDoRangeException;
}

 	