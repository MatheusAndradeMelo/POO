package TrabalhoFinalprograma;

public class ClassificacaoForaDoRangeException extends Exception {

	public ClassificacaoForaDoRangeException(String mensagem) {
		super(mensagem);
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
