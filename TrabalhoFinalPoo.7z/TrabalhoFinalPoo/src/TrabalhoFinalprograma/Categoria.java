package TrabalhoFinalprograma;

public enum Categoria {
	FANTASIA, TERROR , COMEDIA;
}

